<?php
echo number_format($distance, 2) .' '. $shortunit;
?>
