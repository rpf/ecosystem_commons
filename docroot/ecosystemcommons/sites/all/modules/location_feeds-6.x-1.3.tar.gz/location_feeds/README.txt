$Id: README.txt,v 1.1.2.2 2010/06/30 20:06:56 elliottf Exp $

This module provides location feed mappers.  Originally this was created
as a patch for the feeds module (http://drupal.org/node/623428) with work
from

  JayCally        - http://drupal.org/user/297917
  pdrake          - http://drupal.org/user/426817
  clemens.tolboom - http://drupal.org/user/125814

Simple GeoRSS support has been added for points: http://georss.org/simple
Adding support for the other simple georss types should be relatively
easy but would also require support on the node end. Patches welcome.

===
Contact info
Elliott Foster - http://drupal.org/user/61601
http://twitter.com/elliotttf
